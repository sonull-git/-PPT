꼭 압축을 푸시고
index.html 과 pages 폴더, textures 폴더가 같은 경로에 있어야합니다
실행하기 위해서는 index.html 을 열어주시고 전체화면으로 해주세요
Space 키를 누르면 다음 페이지로 넘어갑니다.